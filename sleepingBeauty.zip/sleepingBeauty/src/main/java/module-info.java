module com.example.sleepingbeauty {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.sleepingbeauty to javafx.fxml;
    exports com.example.sleepingbeauty;
}